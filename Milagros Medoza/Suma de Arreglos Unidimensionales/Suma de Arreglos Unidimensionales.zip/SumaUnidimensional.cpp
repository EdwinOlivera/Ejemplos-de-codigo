#include<iostream>
#include<ctime>
using namespace std;

void LlenarArreglo(int *prtA, int dim);
void ImprimirArreglo(int *ptrA, int dim);
void Suma(int *ptrA, int *ptrB, int dim);

int main(){
    //Declare los arreglos y variables necesarias
    srand(time(0));
    //Lea la dimension ingresada por el usuario
    
    //Declare los punteros necesarios
    
    //Haga el llamado a la funcion LlenarArreglo para el puntero de A
    
    //Haga el llamado a la funcion LlenarArreglo para el puntero de B
    cout<<"El primer arreglo es\n";
    //Haga el llamado de la función ImprimirArreglo
    cout<<"El segundo arreglo es\n";
    //Haga el llamado de la función ImprimirArreglo
    cout<<"La suma de los dos arreglos es\n";
    //Haga el llamado de la función Suma

    return 0;
}

//Haga las definiciones de las funciones
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colanodo;

import java.util.Scanner;

/**
 * @author Ricardo Rivera 
 */
public class ColaNodo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Menu();
    }
    
   public static void Menu() {
        String opcion;
        Scanner teclado = new Scanner(System.in); //Creación de un objeto Scanner
        TipoInfo Dato;
        int conteo=0;
        TadCola ColaEstu = new TadCola();
        do {
            agregarLineas(2);
            System.out.println("---------COLA DE DE ATENCIÓN----------");
            System.out.println("1. Nueva solicitud");
            System.out.println("2. Atender");
            System.out.println("3. Ver siguiente estudiante");
            System.out.println("4. Ver cola");
            System.out.println("5. Cantidad de estudiantes");
            System.out.println("s. Salir");
            System.out.println("-----------------------------------------");
            System.out.print("INGRESE LA OPCION [1 - 5]: ");
            opcion = teclado.next();
            opcion=opcion.toLowerCase();
            switch (opcion) {
                case "1":
                    Dato = PideDatos();
                    ColaEstu.meter(Dato);
                    System.out.println("****Dato grabado****");
                    break;
                case "2":
                    if (ColaEstu.ColaVacia()){
                        System.out.println("No hay datos en la cola");
                    }else{
                        Dato = ColaEstu.Sacar();
                        System.out.println("ID:" + Dato.getID());
                        System.out.println("Nombre:" + Dato.getNombre()); 
                    }
                    System.out.println("****Datos que salió****");
                    break;
                case "3":
                    Dato = ColaEstu.verInicio();
                    if (Dato==null){
                        System.out.println("No hay datos");
                    }else{
                        System.out.println("ID:" + Dato.getID());
                        System.out.println("Nombre:" + Dato.getNombre());
                    }
                    System.out.println("****Listo****");
                    break;
                case "4":
                    MostrarCola(ColaEstu);
                    System.out.println("****Pendiente****");
                    break;
                case "5":
                    conteo=ColaEstu.Contar();
                    System.out.println("La cantidad de estudiantes en cola son: "+conteo);
                    System.out.println("****Listo****");
                    break;
                case "s":
                    System.exit(0);
                    break;
                default:
                    break;
            }
            pausa();
        } while (true); //-- SEGUIRA HASTA QUE OPCION SEA IGUAL A 5
    }//fin menu
        
   
    public static void MostrarCola(TadCola pCola){
        TipoNodo aux;
        TipoInfo temp;
        int contar=0;
        if (pCola.ColaVacia()){
            System.out.println("No hay datos que mostrar!!!!!");
        }else{
            aux = pCola.getInicio();
            while (aux!=null){
               //código
               temp=aux.getInfo();
                System.out.println(temp.getID()+"---"+temp.getNombre());
               aux=aux.getSig();
            }
        }
    };

   public static TipoInfo PideDatos() {
        TipoInfo Datos = new TipoInfo();
        Scanner teclado = new Scanner(System.in);
        System.out.println("INTRODUZCA LOS DATOS");
        System.out.print("--ID: ");
        Datos.setID(teclado.nextLine());
        System.out.print("--Nombre: ");
        Datos.setNombre(teclado.nextLine());
        return Datos;
    }

    public static void MostrarDato(TipoInfo tmpDato) {
        if (tmpDato == null) {
            System.out.println("----> LA COLA ESTA VACIA <----");
        } else {
            System.out.println("ID:" + tmpDato.getID() );
            System.out.println("Nombre:" + tmpDato.getNombre());
        }
    }  

  
    //otros métodos
    public final static void agregarLineas(int n) {
        for (int i = 0; i < n; i++) {
            System.out.println();
        }
    }
    
    public final static void pausa(){
        System.out.print("Press Any Key To Continue...");
        new java.util.Scanner(System.in).nextLine();
    }

}

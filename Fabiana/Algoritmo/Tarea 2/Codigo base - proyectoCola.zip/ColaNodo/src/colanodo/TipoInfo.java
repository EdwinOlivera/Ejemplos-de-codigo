package colanodo;

public class TipoInfo {
    private String ID;
    private String nombre;
    
    public TipoInfo() {
        this.ID="";
        this.nombre="";
    }

    public String getID() {
        return ID;
    }

    public String getNombre() {
        return nombre;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }


}

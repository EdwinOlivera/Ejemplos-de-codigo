package Paquete1;

public enum Direcciones {

}

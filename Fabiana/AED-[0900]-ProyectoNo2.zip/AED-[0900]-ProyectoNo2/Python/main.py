from NUCLEO.mainWindow import *

if __name__ == "__main__":
    windows = load()
    windows.load()
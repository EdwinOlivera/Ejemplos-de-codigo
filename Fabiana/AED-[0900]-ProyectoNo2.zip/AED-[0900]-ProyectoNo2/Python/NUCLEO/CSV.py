from NUCLEO.Linkedlist import Node, LinkedList

class CSV:
    # Metodo que lee el archivo donde se guardan los archivos procesados por el programa, el archivo
    def __init__(self, FileName): 
        self.FileName = FileName
        self.content = ""
        self.LL= LinkedList()
        f= open(FileName, "r")
        self.content = f.read()
        f.close()   

    def getContent(self):
        return self.content
    
    #Metodo que genera la tabla a imprimir(Contrasenias.csv)
    def getTable(self): 
        r= ""
        content = self.getContent()
        rows = content.split("\n")

        for i in range(len(rows)):
            row= rows[i].replace(",", "\t|\t")
            r+="-"*195 +"\n"
            if(i==0):
                r+= "%s%s%s%s%s" %("\t\t\t\tContrasenias\t\t\n","-"*195 +"\n","No.\t|rutaOrigen   \t\t|rutaDestino \t\t|Clave \t\n", "-"*195 +"\n", row + "\n")
            else:
                r+= row + "\n"
        return r
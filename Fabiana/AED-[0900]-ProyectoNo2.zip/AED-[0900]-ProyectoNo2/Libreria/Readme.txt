Sistema utilizado basado en Ubunto 18.04

Librerias Utilizadas
networkx

Antes instale pip
	sudo apt install -y python3-pip
Actualice pip
	sudo pip3 install --upgrade pip
Instale networkx
	pip install networkx
Actualizar networkx
	pip install --upgrade networkx
Si decea instalar dependencias opcionales
	pip install networkx[all]

Matplotlib
	sudo apt-get install python-matplotlib
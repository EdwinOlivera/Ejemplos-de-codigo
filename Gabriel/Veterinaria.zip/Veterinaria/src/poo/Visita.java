package poo;

public final class Visita {

	public Visita () {
		
	}
	

}

#include<iostream>
#include <random>
#include <math.h>
#include <iomanip>
#include <cstdlib>

using namespace std;

int Aleatorio( );
long double sumatoria(double , int );
unsigned long long factorial(int );

int main() {
    double x=0;
    int opc=0;
    int valor=0;
    std::cout << "1. Aleatorio" << std::endl
              << "2. Determinista" << std::endl;
    while( opc < 1 || opc > 2 ) {
        std::cin>>opc;
    }
    if( opc == 1){
        valor=Aleatorio();
    }else{
        std::cin>>valor;
    }
    std::cin>>x;
    std::cout<<std::setprecision(16)<<sumatoria(x,valor);
    return 0;
}

int Aleatorio(void) {
  /*En el cuerpo de esta funcion debe generarse de forma aleatoria, la cota
  superior de la sumatoria, considerando la restricción de que esta cota debe
  encontrarse entre 5 y 15 inclusive.*/
}

long double sumatoria(double x , int v) {
/*En el cuerpo de esta funcion, debe realizarla la sumatoria pedida.*/
}

unsigned long long factorial(int n){
/*En este apartado se debe calcular el factorial de el parametro n*/
}
